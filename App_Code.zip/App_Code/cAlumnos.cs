﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for cAlumnos
/// </summary>
public class cAlumnos
{
    public  int Matricula { get; set; }
    public  string Nombre { get; set; }
    public  string Paterno { get; set; }
    public  string Materno { get; set; }
    public string Telefono { get; set; }
    public string Ciudad { get; set; }

    public string Estado { get; set; }
    public int Instituto { get; set; }
    public string Curp { get; set; }

    public string Correo { get; set; }

    public int Carrera { get; set; }

    public int Semestre { get; set; }

}