﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for cVar
/// </summary>
public class cVar
{
    public static string cnnComercializadora { get; set; }
}